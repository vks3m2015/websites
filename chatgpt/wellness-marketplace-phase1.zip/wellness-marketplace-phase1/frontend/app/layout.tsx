import "./globals.css";
import type { Metadata } from "next";

export const metadata: Metadata = {
  title: "Wellora — Wellness Professionals Near You",
  description: "Discover verified wellness professionals and book professional wellness services across Delhi NCR."
};

export default function RootLayout({children}:{children:React.ReactNode}) {
  return <html lang="en"><body>{children}</body></html>;
}
